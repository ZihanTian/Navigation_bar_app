# Landing Page Project



when scrolling, the first section that has a y position that is positive will be highlighted.
when cliking the nav-bar, will automatically scroll to the corresponding section.
WHen staying at a certain section, the nav-bar indicates where you are.
